"""This file is part of the Gudhi Library - https://gudhi.inria.fr/ - which is released under MIT.
    See file LICENSE or go to https://gudhi.inria.fr/licensing/ for full license details.
    Author(s):       Vincent Rouvreau

   Copyright (C) 2019  Inria

   Modification(s):
     - YYYY/MM Author: Description of the modification
"""

from setuptools import setup, Extension
from Cython.Build import cythonize
from numpy import get_include as numpy_get_include
import sys

__author__ = "Vincent Rouvreau"
__copyright__ = "Copyright (C) 2016  Inria"
__license__ = "MIT"

modules = ['off_reader', 'simplex_tree', 'rips_complex', 'cubical_complex', 'periodic_cubical_complex', 'reader_utils', 'witness_complex', 'strong_witness_complex', 'bottleneck', 'nerve_gic', ]

source_dir='/build/gudhi.3.1.1/python/gudhi/'
extra_compile_args=['-DBOOST_RESULT_OF_USE_DECLTYPE', '-DBOOST_ALL_NO_LIB', '-DBOOST_SYSTEM_NO_DEPRECATED', '-std=c++14', '-frounding-math', '-DCGAL_HEADER_ONLY', '-DCGAL_USE_GMP', '-DCGAL_USE_GMPXX', '-DCGAL_USE_MPFR', ]
extra_link_args=[]
libraries=['gmp', 'gmpxx', 'mpfr', ]
library_dirs=['/usr/lib64', '/usr/lib64', '/usr/lib64', ]
include_dirs = [numpy_get_include(), '/build/gudhi.3.1.1/python/gudhi/', '/usr/include', '/usr/include', '/build/gudhi.3.1.1/build', '/build/CGAL-5.0.1/include', '/build/boost/include', '/build/gudhi.3.1.1/include', '/build/gudhi.3.1.1/python/include', ]
runtime_library_dirs=['/usr/lib64', '/usr/lib64', '/usr/lib64', ]

# Create ext_modules list from module list
ext_modules = []
for module in modules:
    ext_modules.append(Extension(
        'gudhi.' + module,
        sources = [source_dir + module + '.pyx',],
        language = 'c++',
        extra_compile_args=extra_compile_args,
        extra_link_args=extra_link_args,
        libraries=libraries,
        library_dirs=library_dirs,
        include_dirs=include_dirs,
        runtime_library_dirs=runtime_library_dirs,
        cython_directives = {'language_level': str(sys.version_info[0])},))

setup(
    name = 'gudhi',
    packages=["gudhi","gudhi.representations"],
    author='GUDHI Editorial Board',
    author_email='gudhi-contact@lists.gforge.inria.fr',
    version='3.1.1',
    url='http://gudhi.gforge.inria.fr/',
    ext_modules = cythonize(ext_modules),
    install_requires = ['cython','numpy >= 1.9',],
    setup_requires = ['numpy >= 1.9',],
)
